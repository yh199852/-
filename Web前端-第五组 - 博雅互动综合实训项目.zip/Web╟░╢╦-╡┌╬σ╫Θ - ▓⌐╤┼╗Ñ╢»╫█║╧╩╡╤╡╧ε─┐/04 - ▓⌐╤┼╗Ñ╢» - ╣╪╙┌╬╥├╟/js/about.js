var list = $('.list li')
var listText = $('.right>div')

$(function () {
  console.log()
  list.click(function () {
    list.removeClass('new')
    $(this).addClass('new')

    listText.css('display', 'none')
    $(listText[$(this).index()]).css('display', 'block')

    return false
  })
})  