	var viewbox = document.getElementById('view_box');
	var circle_ul = document.getElementById('top_box_swiper');
	var circle_lis = circle_ul.getElementsByTagName('li');
	var topindex = 0;
	setInterval(function() {
		topindex++;
		if (topindex > 3) {
			topindex = 0;
			viewbox.style["left"] = 0 + "px";
			ChangeCircle(circle_lis, topindex);
		}
		viewbox.style["left"] = (-100 * topindex) + "%";
		ChangeCircle(circle_lis, topindex);
	}, 10000)
	for (var i = 0; i < circle_lis.length; i++) {
		circle_lis[i].topindex = i;
		circle_lis[i].onclick = function() {
			topindex = this.topindex;
			ChangeCircle(circle_lis, topindex);
			viewbox.style["left"] = (-100 * topindex) + "%";
		}
	}

	function ChangeCircle(circle, index) {
		var temp = index > 3 ? 0 : index;
		for (var i = 0; i < circle.length; i++) {
			circle[i].className = "";
		}
		circle[temp].className = "current";
	}

	// 三位轮播
	var carousel = document.getElementById("mid_lunbo");
	var movebox = document.getElementById("mid_lunbo_move");
	var move_img = movebox.getElementsByTagName('ul');
	var circle_ul_two = document.getElementById('mid_lunbo_swiper');
	var circle_list_two = circle_ul_two.getElementsByTagName('li');
	midindex = 0
	setInterval(function() {
		animate(move_img[midindex], {
			"left": -1000
		}, 500);
		midindex++;
		if (midindex > 3) {
			midindex = 0;
		}
		move_img[midindex].style.left = 1000 + "px";
		animate(move_img[midindex], {
			"left": 0
		}, 500);
		ChangeCircle(circle_list_two, midindex);
	}, 5000)

	for (var i = 0; i < circle_list_two.length; i++) {
		circle_list_two[i].midindex = i;
		circle_list_two[i].onclick = function() {
			if(this.midindex < midindex){
				animate(move_img[midindex], {"left": 1000}, 500);
				midindex = this.midindex;
				move_img[midindex].style.left = -1000 + "px";
				animate(move_img[midindex], {"left": 0}, 500);
				ChangeCircle(circle_list_two,midindex);
			}else if(this.midindex > midindex){
				animate(move_img[midindex], {"left": -1000}, 500);
				midindex = this.midindex;
				move_img[midindex].style.left = 1000 + "px";
				animate(move_img[midindex], {"left": 0}, 500);
				ChangeCircle(circle_list_two,midindex);
			}else{
				console.log("啊，你点你自己干嘛，就是这个点啊...")
			}
		}
	}




	/*传统轮播方式
	总时间500毫秒内完成
	500毫秒/20毫秒=25次
	总长100%; 100/25次=4%; 每次动4%;
	*/
	// var carousel=document.getElementById("mid_lunbo");
	// var movebox=document.getElementById("mid_lunbo_move");
	// var circle_ul_two=document.getElementById('mid_lunbo_swiper');
	// var circle_list_two=circle_ul_two.getElementsByTagName('li');
	// var mid_index=0;
	// setInterval(function(){
	// 	mid_index++;
	// 		ChangeCircle(circle_list_two,mid_index);
	// 	    Animate_two(movebox,mid_index,function(){
	// 	    	if(mid_index>3){
	// 	    		Animate_two(movebox,4,function(){
	// 	    			this.style.left = 0 + "px";
	// 			        mid_index = 0;
	// 	    		});	
	// 	    	}
	// 	    });
		
	// },5000)	  
	// for(var i=0;i<circle_list_two.length;i++){
	// 	circle_list_two[i].mid_index = i;
	// 	circle_list_two[i].onclick = function(){
	// 		mid_index = this.mid_index;
	// 		ChangeCircle(circle_list_two,mid_index);
	// 		animate(movebox,{"left":(mid_index*-1000)},500,"Linear",function(){
	// 		});
	// 		}
	// 	}
	// function Animate_two(box,index,callback){
	// 	var attrValue=window.getComputedStyle(box)["left"];
	// 	var Sta=attrValue.split("px")[0];
	// 	var StepLong=1000/25;
	// 	var changeTimer=setInterval(function(){
	// 		Sta-=StepLong;
	// 		box.style["left"]=Sta+"px";
	// 		if(Sta<-1000*index){
	// 			clearInterval(changeTimer);
	// 			box.style["left"]=(-1000*index)+"px";
 //                callback.call(box);
	// 		}
	// 	},20)
	// }
	